// dllmain.h : Declaration of module class.

class CClipboardHelperModule : public CAtlDllModuleT< CClipboardHelperModule >
{
public :
	DECLARE_LIBID(LIBID_ClipboardHelperLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_CLIPBOARDHELPER, "{30535D88-652A-4A60-AC7C-140BAFA4AE3D}")
};

extern class CClipboardHelperModule _AtlModule;
