/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ClipBoard.h"



STDMETHODIMP CClipBoard::GetClipboardText(BSTR* pBstrClipboardText)
{
	if (NULL == pBstrClipboardText)
	{
		return E_INVALIDARG;
	}

	CComBSTR bstrResult = L"";

	if (::OpenClipboard(NULL))
	{
		if (::IsClipboardFormatAvailable(CF_TEXT) || ::IsClipboardFormatAvailable(CF_UNICODETEXT))
		{
			// First try to ge UNICODE text.
			BOOL   bUnicode   = TRUE;
			HANDLE hClipboard = ::GetClipboardData(CF_UNICODETEXT);

			if (NULL == hClipboard)
			{
				// If UNICODE text was not available try to get ANSI text.
				bUnicode   = FALSE;
				hClipboard = ::GetClipboardData(CF_TEXT);
			}

			if (hClipboard != NULL)
			{
				LPCSTR szClipboardData = (LPCSTR)::GlobalLock(hClipboard);

				if (szClipboardData != NULL)
				{
					if (bUnicode)
					{
						LPCWSTR szClipboardWText = (LPCWSTR)szClipboardData;

						bstrResult       = szClipboardWText;
						szClipboardWText = NULL;
					}
					else
					{
						LPCSTR szClipboardText = (LPCSTR)szClipboardData;

						bstrResult      = szClipboardText;
						szClipboardText = NULL;
					}

					::GlobalUnlock(hClipboard);

					*pBstrClipboardText = bstrResult.Detach();
					hClipboard = NULL;
				}
				else
				{
					ATLTRACE("GlobalLock failed in CClipBoard::GetClipboardText\n");
				}
			}
			else
			{
				ATLTRACE("GetClipboardData failed in CClipBoard::GetClipboardText\n");
			}

			hClipboard = NULL;
		}
		else
		{
			ATLTRACE("CF_TEXT NOT available in CClipBoard::GetClipboardText\n");
		}

		BOOL bRes = ::CloseClipboard();
		ATLASSERT(bRes);
	}
	else
	{
		ATLTRACE("Can NOT OpenClipboard in CClipBoard::GetClipboardText\n");
	}

	return S_OK;
}

STDMETHODIMP CClipBoard::SetClipboardText(BSTR bstrClipboardText)
{
	if (NULL == bstrClipboardText)
	{
		return E_INVALIDARG;
	}

	// Empty the clipboard.
	HRESULT hRes = ClearClipboard();

	if (FAILED(hRes))
	{
		return E_FAIL;
	}

	BOOL bErr = FALSE;

	// Put text into clipboard.
	if (::OpenClipboard(NULL))
	{
		// Put unicode text in clipboard.
		if (!SetTextInClipboard(bstrClipboardText))
		{
			bErr = TRUE;
		}

		// Put ansi text in clipboard.
		USES_CONVERSION;
		if (!SetTextInClipboard(W2A(bstrClipboardText)))
		{
			bErr = TRUE;
		}

		BOOL bRes = ::CloseClipboard();
		ATLASSERT(bRes);
	}
	else
	{
		bErr = TRUE;
		ATLTRACE("Can NOT OpenClipboard in CClipBoard::SetClipboardText\n");
	}

	if (bErr)
	{
		return E_FAIL;
	}

	return S_OK;
}


BOOL CClipBoard::SetTextInClipboard(LPCSTR szText)
{
	ATLASSERT(szText != NULL);

	size_t  nCharCount = strlen(szText);
	BOOL    bErr       = FALSE;
	HGLOBAL hglb       = ::GlobalAlloc(GMEM_MOVEABLE, (nCharCount + 1) * sizeof(CHAR));

	if (hglb != NULL)
	{
		LPSTR szBuff = (LPSTR)::GlobalLock(hglb);

		strncpy_s(szBuff, nCharCount + 1, szText, nCharCount);
		szBuff[nCharCount] = L'\0';

		::GlobalUnlock(hglb);

		HANDLE hData = SetClipboardData(CF_TEXT, hglb);
		if (NULL == hData)
		{
			::GlobalFree(hglb);
			hglb = NULL;
			bErr = TRUE;

			ATLTRACE("SetClipboardData failed in CClipBoard::SetTextInClipboard\n");
		}
	}
	else
	{
		bErr = TRUE;
		ATLTRACE("GlobalAlloc failed in CClipBoard::SetTextInClipboard\n");
	}

	return !bErr;
}


BOOL CClipBoard::SetTextInClipboard(LPCWSTR szText)
{
	ATLASSERT(szText != NULL);

	size_t  nCharCount = wcslen(szText);
	BOOL    bErr       = FALSE;
	HGLOBAL hglb       = ::GlobalAlloc(GMEM_MOVEABLE, (nCharCount + 1) * sizeof(WCHAR));

	if (hglb != NULL)
	{
		LPWSTR szBuff = (LPWSTR)::GlobalLock(hglb);

		wcsncpy_s(szBuff, nCharCount + 1, szText, nCharCount);
		szBuff[nCharCount] = L'\0';

		::GlobalUnlock(hglb);

		HANDLE hData = SetClipboardData(CF_UNICODETEXT, hglb);
		if (NULL == hData)
		{
			::GlobalFree(hglb);
			hglb = NULL;
			bErr = TRUE;

			ATLTRACE("SetClipboardData failed in CClipBoard::SetTextInClipboard\n");
		}
	}
	else
	{
		bErr = TRUE;
		ATLTRACE("GlobalAlloc failed in CClipBoard::SetTextInClipboard\n");
	}

	return !bErr;
}


HRESULT CClipBoard::ClearClipboard()
{
	HRESULT hRes = S_OK;

	if (::OpenClipboard(NULL))
	{
		BOOL bRes = ::EmptyClipboard();
		if (!bRes)
		{
			ATLTRACE("Can NOT EmptyClipboard in CClipBoard::ClearClipboard\n");
			hRes = E_FAIL;
		}

		bRes = ::CloseClipboard();
		if (!bRes)
		{
			ATLTRACE("Can NOT CloseClipboard in CClipBoard::ClearClipboard\n");
			hRes = E_FAIL;
		}
	}
	else
	{
		ATLTRACE("Can NOT OpenClipboard in CClipBoard::ClearClipboard\n");
		hRes = E_FAIL;
	}

	return hRes;
}
