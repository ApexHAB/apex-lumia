/////////////////////////////////////////////////////////////
// FREE code from CODECENTRIX
// http://www.codecentrix.com/
// http://codecentrix.blogspot.com/
/////////////////////////////////////////////////////////////

var clipboardHelper = null;

try
{
	clipboardHelper = WScript.CreateObject("ClipboardHelper.ClipBoard");
}
catch (ex)
{
	WScript.Echo(ex.message + "\n\nIt seems that ClipboardHelper library is not properly registered.\nPlease run register.bat!");
	WScript.Quit(1);
}

var msg = "FREE code from: http://www.codecentrix.com/";

// Put the text into the clipboard.
clipboardHelper.SetClipboardText(msg);

// Get the text from clipboard.
var text = clipboardHelper.GetClipboardText();

WScript.Echo(text);
